package com.niit.shoppingcartbackend;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackend.dao.CategoryDAO;
import com.niit.shoppingcartbackend.model.Category;

public class CategoryTestJU {
	@Autowired
	CategoryDAO categoryDAO;
	@Autowired
	Category category;

	AnnotationConfigApplicationContext context;
	@Before
	public void init()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		categoryDAO = (CategoryDAO) context.getBean("categoryDAO");
		category = (Category) context.getBean("category");

	}
	@Test
	public void CategoryTestCase()
	{
		int size=categoryDAO.list().size();
		assertEquals("Category List Test Case", 2, size);
		
	}
}
