package com.niit.shoppingcartbackend;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartbackend.dao.UserDAO;
import com.niit.shoppingcartbackend.model.User;

public class UserTest {
	public static void main(String args[])
	{
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartbackend");
		context.refresh();
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		
		User user = (User) context.getBean("user");
		
		user.setId("CG2");
		user.setName("CGName2");
		user.setAddress("Bangalore");
		user.setMail("asas@g.com");
		user.setPassword("1223");
		user.setMobile(9876583210L);
		
		//userDAO.delete("CG1");
		
		userDAO.saveOrUpdate(user);

	}
}
