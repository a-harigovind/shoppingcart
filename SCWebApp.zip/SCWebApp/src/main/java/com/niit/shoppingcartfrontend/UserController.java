package com.niit.shoppingcartfrontend;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcartbackend.dao.UserDAO;
import com.niit.shoppingcartbackend.model.User;

@Controller
public class UserController {
	
	@Autowired
	UserDAO userDAO;
	@Autowired
	User user;

	@RequestMapping("/")
	public String getLanding()
	{
		System.out.println("Index page called....");
		return "index";
	}
	
	@RequestMapping("/home")
	public String getHome() {
		System.out.println("Home....");
		return "index";
	}
	
	@RequestMapping("/about")
	public String getAbout() {
		System.out.println("About....");
		return "about";
	}

	@RequestMapping("/contact")
	public String getContact() {
		System.out.println("Contact....");
		return "contactus";
	}

	@RequestMapping("/sign")
	public ModelAndView getSign() {
		System.out.println("Sign In....");
		ModelAndView mv= new ModelAndView("/signup");
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping("/login")
	public String getLogin() {
		System.out.println("logIn....");
		return "login";
	}
	@RequestMapping("/check")
	public ModelAndView login (@RequestParam(name="id") String id, @RequestParam(value="pwd") String Password)
	{
		ModelAndView mv;
		user=userDAO.get(id);
		if(user==null)
		{
			mv=new ModelAndView("/login");
			mv.addObject("msg", "Invalid User");

		}
		else
		{
			if(user.getPassword().equals(Password))
			{
				mv=new ModelAndView("/welcome");
				mv.addObject("msg", "Welcome");
			}
			else
			{
				mv=new ModelAndView("/login");
				mv.addObject("msg", "Invalid Password");
			}

			
		}
		System.out.println("Login Called....");
		return mv;
	}
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ModelAndView register(@ModelAttribute("user") User user)
	{
		userDAO.saveOrUpdate(user);
		ModelAndView mv=new ModelAndView("/login");
		mv.addObject("success", "Registered Successfully");
		return mv;
	}
	
}
